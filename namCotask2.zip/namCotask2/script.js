// Использовать Fetch для отправки запроса к REST API и получения списка пользователей. 
// Затем обработать полученные данные и динамически создать элементы для каждого пользователя, отображая их на странице.

//Example 

// Name: Leanne Graham
// Email: Sincere@april.biz
// Phone: 1-770-736-8031 x56442

//Дополнительно можете реализовать функции, такие как сортировка пользователей, добавление новых пользователей, поиск пользователей и обработку ошибок при загрузке данных.

// Для получение данных =>
// https://jsonplaceholder.typicode.com/users


// I didnt wrote all this code because i had some problems and i ask help from chatgpt but this all idea my

const userList = document.getElementById('user-list'); //user-list it is div from html and this is empty we take because all users should can from one list
const loadUsersBtn = document.getElementById('load-users'); // this button is button which when we click thi button users will shown us
const nameInput = document.getElementById('name'); // input which we write name of person
const emailInput = document.getElementById('email');//input which we write name of email
const phoneInput = document.getElementById('phone'); //input which we write phone
const addUserBtn = document.getElementById('add'); // it is button which we add
const searchInput = document.getElementById('search-input'); //search input
const closeBtn = document.getElementById('close-btn'); // close button

loadUsersBtn.addEventListener('click', () => { // when we click this button
	fetch('https://jsonplaceholder.typicode.com/users') // it is fetch link which we take list of dataes
		.then(res => res.json()) // and all this we should take in style json it is like "aman: zhaman"
		.then(users => { // users which each users will be saven

			users.forEach(user => { // from users we can take user
				const userDiv = document.createElement('div'); //we oppened new div from html but we can not show it frrom html
				userDiv.classList.add('user'); //user it is each data that we will take from fetch

				const name = document.createElement('p'); // also in here we can take p from html but we can not see it from here
				name.textContent = `Name: ${user.name}`;  // we will take p by name "name" and after we will take user name

				const email = document.createElement('p'); //aslo here like that but email
				email.textContent = `Email: ${user.email}`;

				const phone = document.createElement('p'); // in here also like that bu only phone
				phone.textContent = `Phone: ${user.phone}`;

				userDiv.appendChild(name); //we will creat it in main page
				userDiv.appendChild(email); // also like that but only email
				userDiv.appendChild(phone); // here phone we can

				userList.appendChild(userDiv);
			});
		})
});

addUserBtn.addEventListener('click', () => { // when we click add button 
	const newUser = {
		name: nameInput.value, // it is values that we will import for main page but it is only name of perso
		email: emailInput.value, //in here only email
		phone: phoneInput.value // phone
	};

	const userDiv = document.createElement('div');
	userDiv.innerHTML = `
        <p>Name: ${newUser.name}</p> 
        <p>Email: ${newUser.email}</p>
        <p>Phone: ${newUser.phone}</p>
    `; // in here we will import to main page that we be ablity to show it
	userList.appendChild(userDiv); // and also like that
});

searchInput.addEventListener('input', () => { // when we write somethinkg to input button
	const searchText = searchInput.value;  // we import this one
	const users = userList.querySelectorAll('.user');

	users.forEach(user => { //we take each user
		const name = user.querySelector('p').textContent.toLowerCase(); 
		if (name.includes(searchText)) { // when value have in input text it will show us
			user.style.display = 'block';
		} else {
			user.style.display = 'none'; // if have nor it will not show us it
		}
	});
});
